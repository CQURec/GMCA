# -*- coding: utf-8
"""
@author：67543
@date：  2022/4/18
@contact：675435108@qq.com
"""
import pickle

from util import *
from tools import *


def predict():
    results = []
    with open(result_path + "/uniteModels_result.txt", 'a') as f:
        for cnt, uid in enumerate(test_uids):
            metrics = "pre@5={},rec@5={},ndcg@5={},pre@10={},rec@10={},ndcg@10={}," \
                      "pre@15={},rec@15={},ndcg@15={},pre@20={},rec@20={},ndcg@20={}"
            FUC_score = [PFM.predict(uid, lid) * (MGMWT.predict(uid, lid) + MGMLT.predict(uid, lid))
                              * TAMF.predict(uid, lid) * LFBCA.predict(uid, lid)
                              if (uid, lid) not in training_tuples else -1
                              for lid in all_lids]
            FUC_score,GCN_score = np.array(FUC_score), scores[uid]
            unite_score = (1-args.gnn_w)*FUC_score+args.gnn_w*GCN_score
            predict_topk = list(reversed(unite_score.argsort()))[:top_k]
            actual = ground_truth[uid]
            result = get_metrics(actual, predict_topk)
            metrics = metrics.format(*result)
            results.append(result.tolist())
            str_reslut = '\t'.join(str(i) for i in result.tolist())
            print(cnt, uid, metrics)
            f.write(str_reslut + '\n')
        results = np.array(results)
        final_gnn_resuluts = np.mean(results, axis=0)
        metrics = "pre@5={},rec@5={},ndcg@5={},pre@10={},rec@10={},ndcg@10={}," \
                  "pre@15={},rec@15={},ndcg@15={},pre@20={},rec@20={},ndcg@20={}".format(*final_gnn_resuluts)
        print(metrics)

if __name__ == '__main__':
    """
      1.基本配置
   """
    args = parse_args()
    temp_path, result_path = get_config(args, "uniteModel")
    data_name = args.dataset
    FUC_load_path = "./uniteModels/" + data_name + "-FUC/"
    GCN_load_path = "./uniteModels/" + data_name + "-GCN/"
    """
   2.加载测试数据
   """
    with open("processed/" + data_name + "/graph.pkl", 'r') as f:
        _, _, test_U2I, _, _ = pickle.load(f), pickle.load(f), pickle.load(f),pickle.load(f),pickle.load(f)
        user_num, poi_num = pickle.load(f)
    with open("processed/" + data_name + "/fuc.pkl", 'r') as f:
        _, training_tuples, _, _, _ = pickle.load(f), pickle.load(f), pickle.load(f), pickle.load(f), pickle.load(f)
        sparse_training_matrix_WT, sparse_training_matrix_LT = pickle.load(f), pickle.load(f)
        ground_truth, poi_coos = pickle.load(f), pickle.load(f),
    test_uids = test_U2I.keys()
    # all_uids, all_lids, test_uids = list(range(user_num)), list(range(poi_num)), ground_truth.keys()
    all_uids, all_lids, test_uids = list(range(user_num)), list(range(poi_num)), test_U2I.keys()
    np.random.shuffle(test_uids)
    """
   3.初始化模块
   """
    PFM = PoissonFactorModel(K=30, alpha=20.0, beta=0.2)
    MGMWT = MultiGaussianModel(alpha=0.2, theta=0.02, dmax=15)
    MGMLT = MultiGaussianModel(alpha=0.2, theta=0.02, dmax=15)
    TAMF = TimeAwareMF(K=100, Lambda=1.0, beta=2.0, alpha=2.0, T=24)
    LFBCA = LocationFriendshipBookmarkColoringAlgorithm(alpha=0.85, beta=float(args.beta), epsilon=0.001)
    """
   4.模块参数装配
   """
    user_embed, item_embed = torch.load(GCN_load_path + data_name + "-graph_model.pth")
    scores = np.matmul(user_embed, item_embed.T)
    PFM.load_model(FUC_load_path)
    MGMWT.multi_center_discovering(sparse_training_matrix_WT, poi_coos)
    MGMLT.multi_center_discovering(sparse_training_matrix_LT, poi_coos)
    TAMF.load_model(FUC_load_path)
    LFBCA.load_model(FUC_load_path)
    """
      5.模块预测
      """
    predict()
